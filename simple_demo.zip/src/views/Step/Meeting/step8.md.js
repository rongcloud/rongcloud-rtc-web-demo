export default `
##### 退出房间
\`\`\`javascript
const { code } = await rtcClient.leaveRoom(room)
\`\`\`
`;
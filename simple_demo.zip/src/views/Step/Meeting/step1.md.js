export default `
#### 1、在项目中进行依赖安装：如下所示
\`\`\`javascript
npm install @rongcloud/engine@latest @rongcloud/imlib-next@latest @rongcloud/plugin-rtc@latest -S
\`\`\`
`;
export default `
\`\`\`javascript
const { code } = await rtcClient.leaveLivingRoomAsAudience(room)
\`\`\`
`;
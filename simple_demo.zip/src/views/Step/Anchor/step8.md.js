export default `
\`\`\`javascript
const { code } = await rtcClient.leaveRoom(room)
\`\`\`
`;